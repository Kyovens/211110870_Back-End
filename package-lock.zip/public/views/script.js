document.addEventListener('DOMContentLoaded', function () {
    var carousels = bulmaCarousel.attach();
    var carousel = carousel[0];
    var nextButton = document.querySelector('.caarousel-nav-right');
    var prevButton = document.querySelector('.carousel-nav-left');

    nextButton.addEventListener('click', function () {
        carousel.next();
    });

    prevButton.addEventListener('click', function() {
        carousel.previous();
    });
});