import { Sequelize, DataTypes } from "sequelize";
import User from "../controllers/user";
import { sequelize } from "./model";

const User = Sequelize.define('user',{
    userid: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    active: {
        type: DataTypes.TINYINT
    }
});

sequelize.sync().then (() => {
    console.log('User table created')
});

// User.create({
//     username: 'Alvyn',
//     password: 'Alvyn123'
// }).then (user => {
//     console.log('User created', user);
// });

const userid = document.getElementById ('userid').value;
const username = document.getElementById('username').value;
const password = document.getElementById('password').value;

User.create({
    userid: userid,
    username: username,
    password: password
}).then(user => {
    console.log('User Created', user)
})

export default User;