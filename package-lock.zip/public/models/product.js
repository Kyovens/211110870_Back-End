import {sequelize, DataTypes} from "./model";

const Product = sequelize.define('product','nama','price', {
    name: DataTypes.STRING,
    price: DataTypes.INTEGER
});

export default Product;